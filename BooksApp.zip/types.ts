export interface Book {
    id: string;
    title: string;
    description: string;
    year: string;
    cover: string;
  }